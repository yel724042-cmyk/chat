<h3 align="center">Form Login </h3>
<form  name="formlogin" action="" method="POST" id="login" class="form-horizontal">
  <div class="form-group">
    <div class="col-sm-12">
      <input type="text"  name="Username" class="form-control" required placeholder="Username" />
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-12">
      <input type="password" name="Password" class="form-control" required placeholder="Password" />
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-12">
      <button type="submit" class="btn btn-primary" id="btn"> <span class="glyphicon glyphicon-log-in"> </span> Login </button>
    </div>
  </div>
</form>