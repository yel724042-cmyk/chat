<div class="list-group">
  <a href="index.php" class="list-group-item active">
    เมนูหลัก
  </a>
  <a href="form.php" class="list-group-item">แบบฟอร์มการแจ้ง</a>
  <a href="showlist.php" class="list-group-item">แสดงรายการแจ้ง</a>
</div>