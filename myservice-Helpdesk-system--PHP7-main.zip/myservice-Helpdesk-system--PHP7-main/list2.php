<div class="list-group">
  <a href="admin.php" class="list-group-item active">
    เมนูหลัก
  </a>
  <a href="new_case.php" class="list-group-item">-ข้อมูลแจ้งซ่อม</a> 
  <a href="device.php" class="list-group-item">-จัดการอุปกรณ์</a>
  <a href="member.php" class="list-group-item">-จัดการช่าง</a>
  <a href="status.php" class="list-group-item">-สถานะการแจ้งซ่อม</a>
  <a href="report_count.php" class="list-group-item">-สถิติ</a>
  <a href="report_all.php" class="list-group-item">-รายงาน</a>
 <a href="report_all_complete.php" class="list-group-item">-รายงานซ่อมเสร็จ</a>
  <a href="logout.php" class="list-group-item list-group-item-danger">-ออกจากระบบ</a>

</div>