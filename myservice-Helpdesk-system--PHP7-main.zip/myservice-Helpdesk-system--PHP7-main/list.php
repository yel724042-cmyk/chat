<div class="list-group">
  <a href="admin.php" class="list-group-item active">
    เมนูหลัก
  </a>
 
  <a href="device.php" class="list-group-item">จัดการอุปกรณ์</a>
  <!-- 
  <a href="admin.php" class="list-group-item">เพิ่มผู้ดูแลระบบ</a>
  <a href="Private.php" class="list-group-item">เพิ่มแจ้งปัญหาการใช้คอมพิวเตอร์</a>
  <a href="Report.php" class="list-group-item">เพิ่มรายละเอียดการซ่อม</a>
  <a href="status.php" class="list-group-item">เพิ่มสถานะการซ่อม</a>
  -->
</div>